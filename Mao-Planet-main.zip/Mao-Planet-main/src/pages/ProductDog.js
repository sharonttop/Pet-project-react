function ProductDog(props) {
//   const { auth } = props
  return (
    <>
      <h1>狗狗館</h1>
    </>
  )
}

export default ProductDog
