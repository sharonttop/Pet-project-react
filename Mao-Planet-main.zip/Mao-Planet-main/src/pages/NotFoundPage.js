function NotFoundPage(props) {
  return (
    <>
      <h1>404 找不到網頁</h1>
    </>
  )
}

export default NotFoundPage
