function ProductCat(props) {
//   const { auth } = props
  return (
    <>
      <h1>貓貓館</h1>
    </>
  )
}

export default ProductCat
