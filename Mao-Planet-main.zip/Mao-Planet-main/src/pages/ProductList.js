import { withRouter } from 'react-router-dom'

function ProductList(props) {
  console.log(props)

  // const { auth } = props

  return (
    <>
      <h1>毛孩雜貨</h1>
    </>
  )
}

export default withRouter(ProductList)
