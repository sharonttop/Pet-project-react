import { withRouter } from 'react-router-dom'

function AdoptList(props) {
  console.log(props)

  // const { auth } = props

  return (
    <>
      <h1>毛孩找家</h1>
    </>
  )
}

export default withRouter(AdoptList)
