import React from 'react'
import BlogListBanner from '../../components/BlogListBanner'



function BlogList(props) {
//   const { auth } = props
  return (
    <>
      <BlogListBanner />

    </>
  )
}

export default BlogList
